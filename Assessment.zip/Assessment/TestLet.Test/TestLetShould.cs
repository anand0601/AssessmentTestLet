using System;
using Xunit;
using Assessment;
using System.Collections.Generic;

namespace TestLet.Test
{
    public class TestLetShould
    {

        private List<Item> items;
        private Testlet testLet;

        public TestLetShould()
        {
            CreateList();
        }

        private void CreateList()
        {
            items = new List<Item>()
            {
                new Item(){ ItemId = "0",ItemType = ItemTypeEnum.Pretest},
                new Item(){ ItemId = "1",ItemType = ItemTypeEnum.Operational},
                new Item(){ ItemId = "2",ItemType = ItemTypeEnum.Operational},
                new Item(){ ItemId = "3",ItemType = ItemTypeEnum.Operational},
                new Item(){ ItemId = "4",ItemType = ItemTypeEnum.Pretest},
                new Item(){ ItemId = "5",ItemType = ItemTypeEnum.Pretest},
                new Item(){ ItemId = "6",ItemType = ItemTypeEnum.Operational},
                new Item(){ ItemId = "7",ItemType = ItemTypeEnum.Pretest},
                new Item(){ ItemId = "8",ItemType = ItemTypeEnum.Operational},
                new Item(){ ItemId = "9",ItemType = ItemTypeEnum.Operational},
            };
        }

        [Fact]
        public void ErrorifListIsNull()
        {
            List<Item> listItems = null;

            testLet = new Testlet("1", listItems);

            Assert.Throws<NullReferenceException>(() => testLet.Randomize());
        }

        [Fact]
        public void ErrorifNoItemsinTheList()
        {
            List<Item> listWitoutItems = new List<Item>();

            testLet = new Testlet("1", listWitoutItems);

            Assert.Throws<Exception>(() => testLet.Randomize());
        }

        [Fact]
        public void HaveFristTwoItemsPreTest()
        {
            List<Item> expected = new List<Item>()
            {
                new Item(){ ItemId = "1", ItemType = ItemTypeEnum.Pretest},
                new Item(){ ItemId = "2", ItemType = ItemTypeEnum.Pretest},
            };

            testLet = new Testlet("1", items);

                List<Item> actual = testLet.Randomize();
                for (int i = 0; i < 2; i++)
                {
                    Assert.Equal(expected[i].ItemType, actual[i].ItemType);
                }
            
        }
    }
}
