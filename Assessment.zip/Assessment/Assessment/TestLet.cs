﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Assessment
{
    public class Testlet
    {
        public string TestletId;
        private List<Item> Items;
        private List<int> UsedRandomNum;

        public Testlet(string testletId, List<Item> items)
        {
            TestletId = testletId;
            Items = items;
            UsedRandomNum = new List<int>();
        }
        public List<Item> Randomize()
        {
            //Items private collection has 6 Operational and 4 Pretest Items.
            //Randomize the order of these items as per the requirement(with TDD)


            //assuming that the list always have 6 Operational and 4 Pretest items but in diffrent order or same.
            if (Items == null)
            {
                throw new NullReferenceException();
            }
            if (Items.Count == 0)
            {
                throw new Exception("There are no Items available.");
            }

            ArrangeItems();

            int i = 0, min = 0, max = Items.Count(), index = 0;

            while (i < max)
            {
                min = (i < 2) ? 6 : 2;
                index = GetUniqueRandonNum(min, max);
                Swap(i, index);

                i++;
            }

            return Items;
        }

        private void ArrangeItems()
        {
            int i = 0, j = 6;

            while (i < 6 && j < 10)
            {
                while (Items.ElementAt(i).ItemType == ItemTypeEnum.Operational)
                {
                    i++;
                }
                while (Items.ElementAt(j).ItemType == ItemTypeEnum.Pretest)
                {
                    j++;
                }

                Swap(i, j);
                i++; j++;
            }
        }

        private int GetUniqueRandonNum(int min, int max)
        {
            Random random = new Random(DateTime.Now.Millisecond);
            int num = random.Next(min, max);

            while (UsedRandomNum.Contains(num) && UsedRandomNum.Count < 8)
            {
                num = random.Next(min, max);
            }

            UsedRandomNum.Add(num);
            return num;
        }

        private void Swap(int i, int j)
        {
            var tempItem = Items.ElementAt(i);
            Items[i] = Items.ElementAt(j);
            Items[j] = tempItem;
        }

    }
    public class Item
    {
        public string ItemId;
        public ItemTypeEnum ItemType;
    }
    public enum ItemTypeEnum
    {
        Pretest = 0,
        Operational = 1
    }
}