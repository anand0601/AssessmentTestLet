﻿using System;
using System.Collections.Generic;

namespace Assessment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            int i = 0;
            while (i < 50)
            {
                List<Item> items = new List<Item>()
            {
                new Item(){ ItemId = "0",ItemType = ItemTypeEnum.Pretest},
                new Item(){ ItemId = "1",ItemType = ItemTypeEnum.Operational},
                new Item(){ ItemId = "2",ItemType = ItemTypeEnum.Operational},
                new Item(){ ItemId = "3",ItemType = ItemTypeEnum.Operational},
                new Item(){ ItemId = "4",ItemType = ItemTypeEnum.Pretest},
                new Item(){ ItemId = "5",ItemType = ItemTypeEnum.Pretest},
                new Item(){ ItemId = "6",ItemType = ItemTypeEnum.Operational},
                new Item(){ ItemId = "7",ItemType = ItemTypeEnum.Pretest},
                new Item(){ ItemId = "8",ItemType = ItemTypeEnum.Operational},
                new Item(){ ItemId = "9",ItemType = ItemTypeEnum.Operational},
            };
                Testlet testlet = new Testlet("Test", items);
                testlet.Randomize();

                foreach (Item item in items)
                {
                    Console.WriteLine(item.ItemType.ToString());
                }

                Console.WriteLine("*************************");

                i++;
            }
            Console.ReadLine();
        }
    }
}
